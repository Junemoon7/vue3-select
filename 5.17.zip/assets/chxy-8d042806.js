const s="/assets/chxy-d724d583.png";export{s as _};
